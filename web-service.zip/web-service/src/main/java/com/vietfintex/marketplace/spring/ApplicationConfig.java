//package com.vietfintex.marketplace.spring;
//
//import org.springframework.context.annotation.ComponentScan;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.ImportResource;
//import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
//
//@Configuration
//@ImportResource({"classpath:spring-security.xml", "classpath:spring-data.xml"})
//@EnableJpaRepositories(basePackages = "com.vietfintex.marketplace.persistence.repo")
//@ComponentScan("com.vietfintex.marketplace")
//public class ApplicationConfig {
//}
